# remake
Remake
Emely Galeano eg2230@bard.edu
February 28, 2022
CMSC 336: Games Systems
Remake Project
Collaboration Statement: I worked alone on this assigment with assistance from https://github.com/nesbox/TIC-80/wiki/Snake-Clone-tutorial .
